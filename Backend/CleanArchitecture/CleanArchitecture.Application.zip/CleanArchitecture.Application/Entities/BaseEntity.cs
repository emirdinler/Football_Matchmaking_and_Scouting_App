using System;
using System.Collections.Generic;


namespace CleanArchitecture.Core.Entities
{
    public abstract class BaseEntity
    {
        public int Id { get; set; }
    }
}
