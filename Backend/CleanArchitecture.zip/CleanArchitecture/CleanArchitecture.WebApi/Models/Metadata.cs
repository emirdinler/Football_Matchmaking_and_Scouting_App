﻿namespace CleanArchitecture.WebApi.Models
{
    public class Metadata
    {
    }
}
